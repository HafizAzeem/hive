@extends('layouts.master_backend')
@section('content')
<script>
    $(".datePickerDefault").datepicker({
        dateFormat: 'yy-mm-dd',
        format: 'L',
        minDate: 0
    });
</script>
@php 
      if(isset($data_row[0]) && !empty($data_row[0])){
          $flag=1;
          $heading=lang_trans('btn_update');
      }
  @endphp
  
<div class="">
  <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
              <div class="x_title">
                  <h2>Extra Revenue</h2>
                  <div class="clearfix"></div>
              </div>
              <div class="x_content">
                  <br/>
                  @if($flag==1)
                      {{ Form::model($data_row[0],array('url'=>route('save-extrarevenue'),'id'=>"edit-extrarevenue-form", 'class'=>"form-horizontal form-label-left")) }}
                      {{Form::hidden('id',null)}}
                  @endif
                    <div class="row">
                        <div class="col-md-6 col-sm-4 col-xs-12">
                            <label class="control-label"> Title <span class="required">*</span></label>
                            {{Form::text('title',null,['class'=>"form-control col-md-6 col-xs-12", "id"=>"title",'required'])}}
                        </div>
                        <div class="col-md-6 col-sm-4 col-xs-12">
                            <label class="control-label"> Payment <span class="required">*</span></label>
                            {{Form::text('payment',null,['class'=>"form-control col-md-6 col-xs-12", "id"=>"payment1",'required'])}}
                        </div>
                        <div class="col-md-6 col-sm-3 col-xs-12">
                            <label class="control-label"><span class="required">*</span> Payment Mode</label>
                            {{Form::select('mode',$payment_mode_list ?? '',null,['class'=>"form-control col-md-6 col-xs-12","id"=>"payment", "placeholder"=>"--Select", 'required'])}}
                        </div>
                        <div class="col-md-6 col-sm-4 col-xs-12">
                            <label class="control-label"> Remark <span class="required">*</span></label>
                            {{Form::text('remark',null,['class'=>"form-control col-md-6 col-xs-12", "id"=>"remark",'required'])}}
                        </div>
                        
                        <div class="col-md-4 col-sm-4 col-xs-12">
                            <label class="control-label"> Date <span class="required">*</span></label>
                            {{Form::date('payment_date', null,['class'=>"form-control col-md-6 col-xs-12", "id"=>"payment_date", "autocomplete"=>"off",'required'])}}
                        </div>
                        
                    </div>
                    <div class="ln_solid"></div>
                    <div class="col-md-12 col-sm-12 col-xs-12 text-right">
                        <button class="btn btn-success" type="submit">{{lang_trans('btn_submit')}}</button>
                    </div>
                  {{Form::close()}}
              </div>
          </div>
      </div>
  </div>
</div>
<script>
//   $(function() {

//       $(".datePickerDefault1").datepicker({
//         dateFormat: 'dd-mm-yy',
//          changeMonth: true,
//           changeYear: true,
//           yearRange: "-50:+0"
//       });
//   });
   
    // $(document).ready(function() {
    //     $("#check_in_date_my").datepicker({
    //       startDate: '-0d',
    //     });
    //     $(document).on('click', '.btn-submit-form', function(e) {
    //         v = $(check_in_date_my).val();
    //         // v1 = $(check_out_date_my).val();
    //         var d1 = new Date(v);
    //         //  var d2 = new Date(v1);
    //     });
    // });
</script>
@endsection